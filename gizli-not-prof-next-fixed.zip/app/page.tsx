'use client'
import { useState } from 'react'
import { motion } from 'framer-motion'
import { encodeNote } from '../../lib/utils'

export default function HomePage() {
  const [note, setNote] = useState('')
  const [link, setLink] = useState('')

  const handleShare = () => {
    const encoded = encodeNote(note)
    const url = window.location.origin + '/view/' + encoded
    setLink(url)
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-purple-100 to-blue-100 p-6">
      <div className="max-w-xl mx-auto bg-white p-6 rounded-xl shadow-md">
        <h1 className="text-3xl font-bold text-purple-700 mb-4">Gizli Not</h1>
        <textarea
          className="w-full p-3 border rounded mb-4"
          rows={6}
          placeholder="Notunu yaz..."
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
        <button className="bg-purple-500 text-white px-4 py-2 rounded" onClick={handleShare}>
          Paylaşım Linki Oluştur
        </button>
        {link && (
          <div className="mt-4">
            <p className="text-sm mb-1">Link:</p>
            <input className="w-full border p-2 rounded" value={link} readOnly />
          </div>
        )}
      </div>
    </main>
  )
}